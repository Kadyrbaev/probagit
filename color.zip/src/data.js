export const data =[
    {name: "Sadyr", id: 'b1', age: 22},
    {name: "Jon", id: 'b2', age: 23},
    {name: "Mery", id: 'b3', age: 56},
    {name: "Scott", id: 'b4', age: 31},
]